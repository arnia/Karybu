Karybu
======

An older php cms refactored to use symfony2 components.
